package BancoCofre;
//classe herdeira real
public class Real extends Moeda{
    public Real(double valor) {
        super(valor, "Brasil");
    }

    @Override
    public double valorEmReais() {
        return this.valor;
    }
}

