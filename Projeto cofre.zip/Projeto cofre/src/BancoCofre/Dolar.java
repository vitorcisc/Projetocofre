package BancoCofre;
//calsse herdeira dolar
public class Dolar extends Moeda{
    public Dolar(double valor) {
        super(valor, "EUA");
    }

    @Override
    public double valorEmReais() {
        // Converter para reais
        return this.valor * 5.51;
    }
}
