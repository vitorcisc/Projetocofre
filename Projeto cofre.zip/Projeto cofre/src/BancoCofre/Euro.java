package BancoCofre;
//classe herdeira Euro
public class Euro extends Moeda {
    public Euro(double valor) {
        super(valor, "Europa");
    }

    @Override
    public double valorEmReais() {
        // Converter para reais
        return this.valor * 6.66; //
    }
}


