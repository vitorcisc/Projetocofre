package BancoCofre;
//classe abstrata mae
public abstract class Moeda {
    protected double valor;
    protected String pais;

    //contrutor moeda
    public Moeda(double valor, String pais) {
        this.valor = valor;
        this.pais = pais;
    }
    public abstract double valorEmReais();
}
