package BancoCofre;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Cofrinho cofrinho = new Cofrinho();
        Scanner scanner = new Scanner(System.in);
        //metodo para menu
        while (true) {
            System.out.println("1. Adicionar moeda");
            System.out.println("2. Remover moeda");
            System.out.println("3. Listar moedas");
            System.out.println("4. Calcular total em reais");
            System.out.println("5. Sair");
            System.out.print("Escolha uma opção: ");
            int opcao = scanner.nextInt();

            switch (opcao) {
                //metodo para adicionar moeda
                case 1:
                    System.out.print("Digite o valor da moeda: ");
                    double valor = scanner.nextDouble();
                    System.out.print("Digite o país da moeda (EUA, Europa, Brasil): ");
                    String pais = scanner.next();
                    if (pais.equals("EUA")) {
                        cofrinho.adicionarMoeda(new Dolar(valor));
                    } else if (pais.equals("Europa")) {
                        cofrinho.adicionarMoeda(new Euro(valor));
                    } else if (pais.equals("Brasil")) {
                        cofrinho.adicionarMoeda(new Real(valor));
                    }
                    break;
                case 2:
                    // metodo para excluir moeda
                    System.out.print("Digite o valor da moeda que deseja remover: ");
                    double valorRemover = scanner.nextDouble();
                    System.out.print("Digite o país da moeda que deseja remover (EUA, Europa, Brasil): ");
                    String paisRemover = scanner.next();
                    Moeda moedaRemover = null;
                    for (Moeda moeda : cofrinho.moedas) {
                        if (moeda.valor == valorRemover && moeda.pais.equals(paisRemover)) {
                            moedaRemover = moeda;
                            break;
                        }
                    }
                    if (moedaRemover != null) {
                        cofrinho.removerMoeda(moedaRemover);
                        System.out.println("Moeda removida com sucesso!");
                    } else {
                        System.out.println("Moeda não encontrada.");
                    }
                    break;
                case 3:// metodo para mostra lista de moedas
                    cofrinho.listarMoedas();
                    break;
                case 4://metodo para converte moedas
                    System.out.println("Total em reais: " + cofrinho.calcularTotalEmReais());
                    break;
                case 5:
                    System.exit(0);
            }
        }
    }


}