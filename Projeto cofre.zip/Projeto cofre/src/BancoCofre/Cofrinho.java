package BancoCofre;

import java.util.ArrayList;

public class Cofrinho {
        ArrayList<Moeda> moedas;

        public Cofrinho() {
            this.moedas = new ArrayList<>();
        }

        public void adicionarMoeda(Moeda moeda) {
            this.moedas.add(moeda);
        }

        public void removerMoeda(Moeda moeda) {
            this.moedas.remove(moeda);
        }

        public void listarMoedas() {
            for (Moeda moeda : this.moedas) {
                System.out.println(moeda.pais + ": " + moeda.valor);
            }
        }

        public double calcularTotalEmReais() {
            double total = 0;
            for (Moeda moeda : this.moedas) {
                total += moeda.valorEmReais();
            }
            return total;
        }
    }

